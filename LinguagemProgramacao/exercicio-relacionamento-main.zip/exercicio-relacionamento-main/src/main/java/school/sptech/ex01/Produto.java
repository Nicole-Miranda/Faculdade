package school.sptech.ex01;

public class Produto {

}
