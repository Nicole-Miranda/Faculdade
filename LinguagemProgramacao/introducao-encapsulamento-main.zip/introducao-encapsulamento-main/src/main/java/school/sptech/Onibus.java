package school.sptech;

public class Onibus {

}
