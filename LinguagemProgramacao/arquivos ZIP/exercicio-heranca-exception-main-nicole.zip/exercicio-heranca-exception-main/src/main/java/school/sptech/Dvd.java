package school.sptech;

import school.sptech.exceptions.DadoInvalidoException;

public class Dvd extends ItemBiblioteca{

    private Integer duracao;

    public Dvd(String titulo, Integer duracao) {
        super(titulo);
        if(duracao == null){
            throw new DadoInvalidoException("Dado duracao esta inválido!");
        }
        this.duracao = duracao;
    }

    public Integer getPrazoEmprestimoDias(){
        return 3;
    }


    public Integer getDuracao() {
        return duracao;
    }

    public void setDuracao(Integer duracao) {
        this.duracao = duracao;
    }
}