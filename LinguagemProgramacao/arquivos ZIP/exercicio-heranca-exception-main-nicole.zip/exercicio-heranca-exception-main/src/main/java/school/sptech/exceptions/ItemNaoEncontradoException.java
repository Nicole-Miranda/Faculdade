package school.sptech.exceptions;

public class ItemNaoEncontradoException extends Exception{

    public ItemNaoEncontradoException(String message) {
        super(message);
    }

}