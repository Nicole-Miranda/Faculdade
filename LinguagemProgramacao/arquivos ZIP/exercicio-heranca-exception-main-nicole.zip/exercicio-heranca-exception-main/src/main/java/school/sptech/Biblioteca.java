package school.sptech;

import school.sptech.exceptions.DadoInvalidoException;

import java.util.ArrayList;

public class Biblioteca {

    private String nome;

    public Biblioteca(String nome) {

        if(nome == null || nome.isBlank()){
            throw new DadoInvalidoException("Nome inválido");
        }
        this.nome = nome;
    }

    public void adicionarItem(ItemBiblioteca item){
        if(item == null){}
        throw new DadoInvalidoException("dado item inválido");
    }


    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}