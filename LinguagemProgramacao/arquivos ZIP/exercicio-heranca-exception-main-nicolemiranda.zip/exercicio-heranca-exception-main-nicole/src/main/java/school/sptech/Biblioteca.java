package school.sptech;

import school.sptech.exceptions.DadoInvalidoException;
import school.sptech.exceptions.ItemIndisponivelException;
import school.sptech.exceptions.ItemNaoEncontradoException;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {

    private String nome;
    private List<ItemBiblioteca> itens;

    public Biblioteca(String nome) {

        if(nome == null || nome.isBlank()){
            throw new DadoInvalidoException("Nome inválido");
        }
        this.nome = nome;
        this.itens = new ArrayList<>();
    }

    public void adicionarItem(ItemBiblioteca item){
        if(item == null){
            throw new DadoInvalidoException("dado item inválido");

        }else{
            itens.add(item);
        }
    }

    public ItemBiblioteca buscarPorTitulo(String titulo){
        if(titulo == null){
            throw new ItemNaoEncontradoException("Titulo não encontrado");
        }else{
            for (ItemBiblioteca item : itens){
                if(item.getTitulo().equalsIgnoreCase(titulo)){
                    return item;
                }
            }

            throw new ItemNaoEncontradoException("Titulo não encontrado");
        }
    }

    public void emprestarItem(String titulo, Usuario usuario) {
        if (titulo == null || usuario == null) {
            throw new DadoInvalidoException("Título ou usuário inválido.");
        }
        ItemBiblioteca item = buscarPorTitulo(titulo);
        try {
            item.emprestar(usuario);
        } catch (ItemIndisponivelException e) {
            System.out.println("Esse item já está emprestado para outro usuário.");
        }
    }

    public void devolverItem(String titulo){
        if(titulo == null){
            throw new DadoInvalidoException("titulo esta nulo");
        }
        buscarPorTitulo(titulo).devolver();
    }

    public Boolean possuiItemDisponivel(String titulo){
        if(titulo == null || titulo.isBlank()){
            throw new DadoInvalidoException("Titulo está nulo");
        }else if(buscarPorTitulo(titulo).getEmprestadoPara() == null){
            return true;
        }else{
            return false;
        }
    }

    public List<ItemBiblioteca> listarDisponiveis(){
      List<ItemBiblioteca> novaLista = new ArrayList<>();
      for(ItemBiblioteca item : itens){
          if(item.getEmprestadoPara() == null){
              novaLista.add(item);
          }
      }

      return novaLista;
    }

    public Integer contarPorTipo(String tipo){
        if(tipo == null || tipo.isBlank() || !(tipo.equalsIgnoreCase("DVD")
        || tipo.equalsIgnoreCase("LIVRO"))){
            throw new DadoInvalidoException("Titulo esta nulo ou em branco");
        }

        Integer contador = 0;

        for(ItemBiblioteca item : itens){
            if(tipo.equalsIgnoreCase("DVD") && item instanceof Dvd){
                contador ++;
            }else if(tipo.equalsIgnoreCase("Livro") && item instanceof Livro){
                contador ++;
            }
        }

        return contador;
    }

    public Integer calcularPrazoMedioEmprestimo(){
        if(itens.isEmpty()){
            return 0;
        }

        Integer contador = 0;

        for(ItemBiblioteca item : itens){
            contador += item.getPrazoEmprestimoDias();
        }

        return contador / itens.size();
    }


    public Integer calcularPrazoMedioPorTipo(String tipo){
        if(tipo == null || tipo.isBlank() || !(tipo.equalsIgnoreCase("DVD")
                || tipo.equalsIgnoreCase("Livro"))){
            throw new DadoInvalidoException("Dado inválido");
        }

        Integer contadorDVD = 0;
        Integer qtdDVD = 0;
        Integer contadoLivro = 0;
        Integer qtdLivro = 0;

        for(ItemBiblioteca item : itens){
            if(tipo.equalsIgnoreCase("DVD") && item instanceof Dvd){
                contadorDVD += item.getPrazoEmprestimoDias();
                qtdDVD ++;
            } else if(tipo.equalsIgnoreCase("Livro") && item instanceof Livro){
                contadoLivro += item.getPrazoEmprestimoDias();
                qtdLivro ++;
            }
        }

        if(tipo.equalsIgnoreCase("DVD")){
            if(qtdDVD == 0){
                return 0;
            }
            return contadorDVD/qtdDVD;
        }

            if(qtdLivro == 0){
                return 0;
            }

            return contadoLivro/qtdLivro;

    }

    public List<ItemBiblioteca> listarEmprestadosPara(Usuario usuario){
        List<ItemBiblioteca> novaLista = new ArrayList<>();
        if(usuario == null){
            throw new DadoInvalidoException("Dado inválido");
        }

        for(ItemBiblioteca item : itens){
            if(item.getEmprestadoPara() != null
                    && item.getEmprestadoPara().getNome().equals(usuario.getNome())){
                novaLista.add(item);
            }
        }
            return novaLista;
    }


    public void devolverTodosDoUsuario(Usuario usuario){
        if(usuario == null){
            throw new DadoInvalidoException("Usuário inválido");
        }

        for(ItemBiblioteca item : itens){
            if(item.getEmprestadoPara() != null
                    && item.getEmprestadoPara().getNome().equals(usuario.getNome())){
                item.devolver();
            }
        }
    }


    public void emprestarVarios(List<String> titulos, Usuario usuario){
        if(titulos == null || usuario == null || titulos.isEmpty()){
            throw new DadoInvalidoException("Dado inválido");
        }

        List<String> titulosVistos = new ArrayList<>();

        for(String titulo : titulos){
            if(titulo == null || titulo.isBlank()){
                throw new DadoInvalidoException("Título inválido");
            }
            if(titulosVistos.contains(titulo.toLowerCase())){
                throw new DadoInvalidoException("Título duplicado");
            }
            titulosVistos.add(titulo.toLowerCase());
        }

        List<ItemBiblioteca> lote = new ArrayList<>();

        for(String titulo : titulos){
            lote.add(buscarPorTitulo(titulo));
        }

        for(ItemBiblioteca item : lote){
            if(item.getEmprestadoPara() != null){
                System.out.println("Não foi possível emprestar o lote: o item '"
                        + item.getTitulo() + "' está indisponível.");
                return;
            }
        }

        for(ItemBiblioteca item : lote){
            try {
                item.emprestar(usuario);
            } catch (ItemIndisponivelException e) {
                System.out.println("Esse item já está emprestado para outro usuário");
            }
        }
    }



    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<ItemBiblioteca> getItens() {
        return itens;
    }

    public void setItens(List<ItemBiblioteca> itens) {
        this.itens = itens;
    }
}