package school.sptech;

public class Roupa {

}
