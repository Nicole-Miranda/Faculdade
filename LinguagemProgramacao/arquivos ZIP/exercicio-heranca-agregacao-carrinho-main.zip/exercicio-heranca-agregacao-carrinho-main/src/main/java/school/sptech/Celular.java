package school.sptech;

public class Celular {

}
