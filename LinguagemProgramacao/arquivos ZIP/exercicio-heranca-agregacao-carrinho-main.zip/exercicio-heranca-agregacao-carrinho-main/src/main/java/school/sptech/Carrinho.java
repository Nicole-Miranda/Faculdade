package school.sptech;

public class Carrinho {

}
