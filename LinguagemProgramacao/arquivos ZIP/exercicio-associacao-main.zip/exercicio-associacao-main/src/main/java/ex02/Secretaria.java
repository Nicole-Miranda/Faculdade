package ex02;

public class Secretaria {
}
