package ex01;

public class Pedido {
}
