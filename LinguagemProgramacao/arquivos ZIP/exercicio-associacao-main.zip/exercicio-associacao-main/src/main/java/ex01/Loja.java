package ex01;

public class Loja {
}
