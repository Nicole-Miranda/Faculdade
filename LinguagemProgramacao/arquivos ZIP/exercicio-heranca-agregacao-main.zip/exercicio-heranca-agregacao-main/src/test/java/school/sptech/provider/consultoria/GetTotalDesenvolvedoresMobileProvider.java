package school.sptech.provider.consultoria;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;
import school.sptech.factory.DesenvolvedorMobileFactory;
import school.sptech.factory.DesenvolvedorWebFactory;

import java.util.List;
import java.util.stream.Stream;

import static school.sptech.factory.DesenvolvedorFactory.build;

public class GetTotalDesenvolvedoresMobileProvider implements ArgumentsProvider {

  @Override
  public Stream<? extends Arguments> provideArguments(ExtensionContext extensionContext) throws Exception {
    Object d1 = build("Paulo", 32, 58.7);
    Object d2 = build("Lívia", 47, 67.3);
    Object d3 = build("Elisa", 34, 45.2);
    Object d4 = build("Yasmin", 45, 49.8);
    Object d5 = build("Tiago", 40, 64.4);

    Object d6 = DesenvolvedorWebFactory.build("Bianca", 32, 68.7, "React", "Django", "PostgreSQL", 12);
    Object d7 = DesenvolvedorWebFactory.build("Enzo", 47, 65.2, "Vue", "Express", "MySQL", 18);
    Object d8 = DesenvolvedorWebFactory.build("Mariana", 34, 52.8, "Angular", "Rails", "MongoDB", 15);
    Object d9 = DesenvolvedorWebFactory.build("Gustavo", 45, 59.5, "Svelte", "Flask", "Oracle", 13);
    Object d10 = DesenvolvedorWebFactory.build("Sofia", 40, 61.3, "Ember", "Laravel", "SQL Server", 16);

    Object d11 = DesenvolvedorMobileFactory.build("Leonardo", 50, 44.7, "iOS", "Swift", 10);
    Object d12 = DesenvolvedorMobileFactory.build("Valentina", 30, 67.4, "Android", "Java", 19);
    Object d13 = DesenvolvedorMobileFactory.build("Joaquim", 37, 52.9, "iOS", "Swift", 14);
    Object d14 = DesenvolvedorMobileFactory.build("Alice", 42, 46.5, "Android", "Kotlin", 11);
    Object d15 = DesenvolvedorMobileFactory.build("Rafael", 39, 68.1, "iOS", "Swift", 17);

    return Stream.of(
        Arguments.of("Deve contar apenas os mobile em lista com desenvolvedores comuns (2 mobile)", "Consultoria 1", 10, List.of(d1, d2, d3, d4, d5, d11, d12), 2),
        Arguments.of("Deve contar apenas os mobile em lista com desenvolvedores web (1 mobile)", "Consultoria 2", 10, List.of(d6, d7, d11, d9, d10), 1),
        Arguments.of("Deve contar todos quando a lista possui apenas desenvolvedores mobile (5 mobile)", "Consultoria 3", 10, List.of(d11, d12, d13, d14, d15), 5),
        Arguments.of("Deve ignorar o desenvolvedor web no meio da lista (4 mobile)", "Consultoria 4", 10, List.of(d11, d12, d7, d13, d14), 4),
        Arguments.of("Deve contar todos quando a lista possui apenas desenvolvedores mobile (3 mobile)", "Consultoria 5", 10, List.of(d11, d13, d15), 3),
        Arguments.of("Consultoria vazia deve retornar 0", "Consultoria 6", 10, List.of(), 0),
        Arguments.of("Sem desenvolvedores mobile (apenas comuns e web) deve retornar 0", "Consultoria 7", 10, List.of(d1, d2, d6, d7), 0)
    );
  }
}
