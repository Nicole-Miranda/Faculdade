package school.sptech.exceptions;

public class DadoInvalidoException {

}