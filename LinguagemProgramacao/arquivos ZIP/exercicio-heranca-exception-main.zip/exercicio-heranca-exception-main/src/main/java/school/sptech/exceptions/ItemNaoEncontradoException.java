package school.sptech.exceptions;

public class ItemNaoEncontradoException {

}