package school.sptech.exceptions;

public class ItemIndisponivelException {

}