package school.sptech;

public class ItemBiblioteca {

}