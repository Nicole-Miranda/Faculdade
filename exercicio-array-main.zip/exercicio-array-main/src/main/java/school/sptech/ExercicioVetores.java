package school.sptech;

public class ExercicioVetores {

}